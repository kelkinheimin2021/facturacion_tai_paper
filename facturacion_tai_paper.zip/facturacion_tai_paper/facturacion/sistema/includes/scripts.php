	<link rel="stylesheet" type="text/css" href="../css/style_general.css">

	<script type="text/javascript" src="js/functions.js"></script>

	<?php include "functions.php"; ?>

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">

	<link rel="stylesheet" href="css/bootstrap.min.css" />

	<script type="text/javascript" src="../js/functions.js"></script>
