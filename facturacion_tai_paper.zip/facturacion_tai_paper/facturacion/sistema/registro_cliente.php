<?php 
	session_start();

	
	include "../conexion.php";

	if(!empty($_POST))
	{
		$alert='';
		if(empty($_POST['nombre']) || empty($_POST['correo']) || empty($_POST['telefono']) || empty($_POST['direccion']))
		{
			$alert='<p class="msg_error">Todos los campos son obligatorios.</p>';
		}else{

			$dni = $_POST['dni'];
			$nombre = $_POST['nombre'];
			$correo = $_POST['correo'];
			$telefono  = $_POST['telefono'];
			$direccion   = $_POST['direccion'];
			$usuario_id = $_SESSION['idUser'];
			
			$result = 0;

			if(is_numeric($dni) and $dni !=0)
			{
				$query = mysqli_query($conection,"SELECT * FROM cliente WHERE dni = '$dni' ");
				$result = mysqli_fetch_array($query);
			}

			if($result > 0)
			{
				$alert='<p class="msg_error">El numero de dni ya existe.</p>';
			}else{
				$query_insert = mysqli_query($conection,"INSERT INTO cliente(dni, nombre, correo, telefono, direccion, usuario_id)
				VALUES('$dni', '$nombre', '$correo', '$telefono','$direccion','$usuario_id')");

			if($query_insert){
				$alert='<p class="msg_save">Cliente guardado satisfactoriamente.</p>';
			}else{
				$alert='<p class="msg_error">Error al guardar el cliente.</p>';
			}
		}
		
	}
	mysqli_close($conection);

	}

?>


<!DOCTYPE html>
<html lang="es_ES">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php include "includes/scripts.php"; ?>
	<title>Nuevo Cliente</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		
		<div class="form_register">
			<h1>Nuevo Cliente</h1>
			<hr>
			<div class="alert"><?php echo isset($alert) ? $alert : ''; ?></div>

			<form action="" method="post">
                
				<label for="nombre">Nombre</label>
				<input type="text" name="nombre" id="nombre" placeholder="Nombre completo">

				<div class="row">
				<div class="col">
				<label for="dni">DNI</label>
				<input type="number" name="dni" id="dni" placeholder="dni">
				</div>

				<div class="col">
                <label for="telefono">Telefono</label>
				<input type="number" name="telefono" id="telefono" placeholder="Teléfono">
				</div>
				</div>
				
				<label for="correo">Correo electrónico</label>
				<input type="email" name="correo" id="correo" placeholder="Correo electrónico">
				
				<label for="direccion">Dirección</label>
				<input type="text" name="direccion" id="direccion" placeholder="Dirección">
				<br>

				<div class="row">
                    <div class="col">
                    <input type="submit" class="btn btn-outline-primary btn-block"  name="registrarCliente" value="Registrar">
                    </div>

					<div class="col">
                    <a class="btn btn-outline-success btn-block" href="lista_clientes.php" role="button">Listar</a>
                    </div>

                    <div class="col">
                    <input type="reset" class="btn btn-outline-danger btn-block"  name="cancelarUsuario" value="Cancelar">
                    </div>
                </div>

			</form>

		</div>

	</section>
	<?php include "includes/footer.php"; ?>
</body>
</html>