<?php 
	
	session_start();
	if($_SESSION['rol'] != 1)
	{
		header("location: ./");
	}

	include "../conexion.php";

	if(!empty($_POST))
	{
		$alert='';
		if(empty($_POST['nombre']) || empty($_POST['dni']) || empty($_POST['telefono']) || empty($_POST['correo']) || empty($_POST['direccion']))
		{
			$alert='<p class="msg_error">Todos los campos son obligatorios.</p>';
		}else{

			$idcliente = $_POST['id'];
			$dni       = $_POST['dni'];
			$nombre    = $_POST['nombre'];
			$telefono  = $_POST['telefono'];
			$correo    = $_POST['correo'];
			$direccion = $_POST['direccion'];

            $result = 0;
            if(is_numeric($dni) and $dni !=0)
            {
                $query = mysqli_query($conection,"SELECT * FROM cliente 
                WHERE (dni = '$dni' AND idcliente != $idcliente) ");

                $result = mysqli_fetch_array($query);

            }

			if($result > 0){
				$alert='<p class="msg_error">El número de dni ya existe.</p>';
			}else{

                if($dni == '')
                {  
                    $dni = 0;
                }

				$sql_update = mysqli_query($conection,"UPDATE cliente
										SET dni='$dni', nombre = '$nombre', 
										telefono='$telefono', correo ='$correo',direccion='$direccion'
										WHERE idcliente= $idcliente");
				
				if($sql_update){
					$alert='<p class="msg_save">cliente modificado correctamente.</p>';
				}else{
					$alert='<p class="msg_error">Error al modificar el cliente.</p>';
				}

			}

		}

	}

	//Mostrar Datos
	if(empty($_REQUEST['id']))
	{
		header('Location: lista_clientes.php');
		mysqli_close($conection);
	}
	$idcliente = $_REQUEST['id'];

	$sql= mysqli_query($conection,"SELECT * FROM cliente									WHERE idcliente= $idcliente ");
	mysqli_close($conection);

	$result_sql = mysqli_num_rows($sql);

	if($result_sql == 0){
		header('Location: lista_clientes.php');
	}else{
		
		while ($data = mysqli_fetch_array($sql)) {
			# code...
			$idcliente  = $data['idcliente'];
			$dni        = $data['dni'];
			$nombre     = $data['nombre'];
			$telefono   = $data['telefono'];
			$correo     = $data['correo'];
			$direccion  = $data['direccion'];

		}
	}

?>

<!DOCTYPE html>
<html lang="es_ES">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php include "includes/scripts.php"; ?>
	<title>Editar Cliente</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		
		<div class="form_register">
			<h1>Editar cliente</h1>
			<hr>
			<div class="alert"><?php echo isset($alert) ? $alert : ''; ?></div>

            <form action="" method="post">

                <input type="hidden" name="id" value="<?php echo $idcliente; ?>">                

				<label for="nombre">Nombre</label>
				<input type="text" name="nombre" id="nombre" placeholder="Nombre completo" value="<?php echo $nombre; ?>">

				<div class="row">
				<div class="col">
                <label for="dni">DNI</label>
				<input type="number" name="dni" id="dni" placeholder="dni" value="<?php echo $dni; ?>">
				</div>

				<div class="col">
                <label for="telefono">Telefono</label>
				<input type="number" name="telefono" id="telefono" placeholder="Teléfono" value="<?php echo $telefono; ?>">
				</div>
				</div>

				<label for="correo">Correo electrónico</label>
				<input type="email" name="correo" id="correo" placeholder="Correo electrónico" value="<?php echo $correo;?>">

				<label for="direccion">Dirección</label>
				<input type="text" name="direccion" id="direccion" placeholder="Dirección" value="<?php echo $direccion; ?>">
				<br>

				<div class="row">
                    <div class="col">
                    <input type="submit" class= "btn btn-outline-success btn-block"  name="registrarCliente" value="Modificar">
                    </div>

                    <div class="col">
                    <a class="btn btn-outline-primary btn-block" href="lista_clientes.php" role="button">Salir</a>
                    </div>

                    <div class="col">
                    <input type="reset" class="btn btn-outline-danger btn-block"  name="cancelarCliente" value="Cancelar">
                    </div>
                </div>

			</form>

		</div>


	</section>
	<?php include "includes/footer.php"; ?>
</body>
</html>