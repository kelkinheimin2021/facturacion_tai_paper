-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3307
-- Tiempo de generación: 25-11-2021 a las 05:57:00
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_facturacion`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `actualizar_precio_producto` (`n_cantidad` INT, `n_precio` DECIMAL(10,2), `codigo` INT)  BEGIN
    	DECLARE nueva_existencia int;
        DECLARE nuevo_total decimal(10,2);
        DECLARE nuevo_precio decimal(10,2);
        
        DECLARE cant_actual int;
        DECLARE pre_actual decimal(10,2);
        
        DECLARE actual_existencia int;
        DECLARE actual_precio decimal(10,2);
        
        SELECT precio, existencia INTO actual_precio, actual_existencia FROM producto WHERE codproducto = codigo;
        
        SET nueva_existencia = actual_existencia + n_cantidad;
        SET nuevo_total = (actual_existencia * actual_precio) + (n_cantidad * n_precio);
        SET nuevo_precio = nuevo_total / nueva_existencia;
        
        UPDATE producto SET existencia = nueva_existencia, precio = nuevo_precio WHERE codproducto = codigo;
        
        SELECT nueva_existencia, nuevo_precio;
        
        END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `idcliente` int(11) NOT NULL,
  `dni` int(11) DEFAULT NULL,
  `nombre` varchar(80) DEFAULT NULL,
  `correo` text NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `usuario_id` int(11) NOT NULL,
  `estatus` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`idcliente`, `dni`, `nombre`, `correo`, `telefono`, `direccion`, `fecha`, `usuario_id`, `estatus`) VALUES
(1, 75896542, 'josé Perez', 'josePerez@gmail.com', 956849562, 'Indoamércia s/n', '2021-11-21 21:55:51', 1, 1),
(2, 87654321, 'Maria', 'maria@gmail.com', 956832654, 'san luis de lucma', '2021-11-21 21:55:51', 1, 1),
(3, 74856598, 'Rosa lopez', 'rosa@gmail.com', 987897987, 'culpon 32', '2021-11-21 21:55:51', 2, 1),
(4, 26598745, 'Julio', 'julio@gmail.com', 908098979, 'las brizas', '2021-11-21 21:55:51', 3, 1),
(5, 25698743, 'Jaqueline', 'jaqueline@gmail.com', 2147483647, 'av. chiclayo', '2021-11-21 21:55:51', 1, 1),
(6, 29356189, 'Juan', 'jaun@gmail.com', 979879987, 'socota', '2021-11-21 21:55:51', 1, 1),
(7, 798798798, 'Roberto', 'roberto@gmail.com', 947483647, 'Lambayeque', '2021-11-21 21:59:51', 1, 1),
(8, 65894235, 'Maria lozano', 'marialozano@gmail.com', 987987987, 'cutervo', '2021-11-21 21:59:51', 2, 1),
(9, 78965230, 'Lucinda', 'lucinda@gmail.com', 979879871, 'Chachapoyas', '2021-11-21 21:59:51', 3, 1),
(10, 58963215, 'Lucas', 'lucas@gmail.com', 950206894, 'nuevo culpon', '2021-11-21 21:59:51', 1, 1),
(11, 898798798, 'Carlos Miguel', 'carlosmiguel@gmail.com', 987965982, 'Cruz de motupe', '2021-11-21 21:59:51', 1, 1),
(12, 26985032, 'Nicolle Jazmin', 'nicolle@gmail.com', 947483647, 'Culpon', '2021-11-21 21:59:51', 1, 1),
(13, 12345678, 'kelkin', 'kelkin@gmail.com', 2147483647, 'av. chiclayo', '2021-11-21 17:49:49', 1, 1),
(14, 74758965, 'Nataly fernandez', 'nataly@gmail.com', 2147483647, 'av. chiclayo', '2021-11-21 17:54:11', 1, 1),
(15, 75489625, 'Paola Luna L', 'paola@gmail.com', 2147483647, 'jlo', '2021-11-21 17:55:20', 1, 1),
(16, 745896598, 'Giancarlo', 'giancarlo@hotmail.com', 965823659, 'la victoria', '2021-11-21 17:57:04', 2, 1),
(17, 27265895, 'Tineo', 'tineo@hotmail.com', 956895654, 'lambayeque', '2021-11-21 18:00:07', 3, 1),
(18, 78596521, 'Maria luiza', 'marialuisa@hotmail.com', 2147483647, 'SJL', '2021-11-21 18:09:02', 1, 1),
(19, 36598526, 'Paola Luna L', 'paolaluna@hotmail.com', 2147483647, 'jlo', '2021-11-21 18:15:03', 1, 1),
(20, 29865945, 'Thalia', 'thalia@hotmail.com', 2147483647, 'cutervo', '2021-11-21 22:12:34', 2, 1),
(21, 98652358, 'Maria Peres', 'mariaperes@hotmail.com', 956826595, 'mexico', '2021-11-22 10:39:04', 3, 1),
(22, 112336545, 'Juan', 'juan@gmail.com', 2147483647, 'av. chiclayo', '2021-11-22 11:21:05', 1, 0),
(23, 78596523, 'Paola Luna f', 'Ldelgadokelkinh@crece.uss.edu.pe', 2147483647, 'jlo', '2021-11-23 11:33:43', 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detallefactura`
--

CREATE TABLE `detallefactura` (
  `correlativo` bigint(11) NOT NULL,
  `nofactura` bigint(11) DEFAULT NULL,
  `codproducto` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `preciototal` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_temp`
--

CREATE TABLE `detalle_temp` (
  `correlativo` int(11) NOT NULL,
  `nofactura` bigint(11) NOT NULL,
  `codproducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `preciototal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entradas`
--

CREATE TABLE `entradas` (
  `correlativo` int(11) NOT NULL,
  `codproducto` int(11) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `usuario_id` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `entradas`
--

INSERT INTO `entradas` (`correlativo`, `codproducto`, `fecha`, `cantidad`, `precio`, `usuario_id`) VALUES
(1, 1, '2021-11-23 14:01:58', 150, '110.00', 1),
(2, 2, '2021-11-23 14:01:58', 100, '1500.00', 1),
(3, 3, '2021-11-23 14:01:58', 200, '250.00', 9),
(4, 4, '2021-11-23 14:01:58', 50, '10000.00', 1),
(5, 5, '2021-11-23 14:01:58', 100, '500.00', 1),
(6, 6, '2021-11-23 14:01:58', 8, '2000.00', 1),
(7, 7, '2021-11-23 14:01:58', 75, '2200.00', 1),
(8, 8, '2021-11-23 14:01:58', 75, '160.00', 1),
(9, 9, '2021-11-23 14:01:58', 0, '45.00', 1),
(10, 10, '2021-11-23 14:04:33', 0, '45.00', 1),
(11, 11, '2021-11-23 14:05:37', 0, '45.00', 1),
(12, 12, '2021-11-23 14:07:09', 0, '45.00', 1),
(13, 13, '2021-11-23 14:09:46', 33, '1222.00', 1),
(14, 14, '2021-11-23 14:10:24', 33, '1222.00', 1),
(15, 15, '2021-11-23 14:11:24', 5, '56.00', 1),
(16, 16, '2021-11-23 14:14:21', 5, '56.00', 1),
(17, 17, '2021-11-23 14:15:01', 2, '54.00', 1),
(18, 18, '2021-11-23 14:22:27', 2, '54.00', 1),
(19, 19, '2021-11-23 17:47:59', 5, '2900.00', 1),
(20, 20, '2021-11-23 21:00:25', 22, '12.00', 1),
(21, 21, '2021-11-24 15:43:46', 6, '13.00', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `nofactura` bigint(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `usuario` int(11) DEFAULT NULL,
  `codcliente` int(11) DEFAULT NULL,
  `totaltactura` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `codproducto` int(11) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `proveedor` int(11) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `existencia` int(11) DEFAULT NULL,
  `date_add` datetime NOT NULL DEFAULT current_timestamp(),
  `usuario_id` int(11) NOT NULL,
  `estatus` int(11) NOT NULL DEFAULT 1,
  `foto` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`codproducto`, `descripcion`, `proveedor`, `precio`, `existencia`, `date_add`, `usuario_id`, `estatus`, `foto`) VALUES
(1, 'Mouse', 11, '97.33', 300, '2021-11-23 14:01:58', 1, 1, 'img_producto.png'),
(2, 'Monitor ', 3, '1016.67', 150, '2021-11-23 14:01:58', 1, 1, 'img_producto.png'),
(3, 'Teclado', 9, '250.00', 200, '2021-11-23 14:01:58', 7, 1, 'img_producto.png'),
(4, 'mouse', 5, '10000.00', 50, '2021-11-23 14:01:58', 1, 1, 'img_21084f55f7b61c8baa2726ad0b4a1dca.jpg'),
(5, 'cuaderno', 6, '500.00', 100, '2021-11-23 14:01:58', 1, 1, 'img_25c1e2ae283b99e83b387bf800052939.jpg'),
(6, 'Monitor', 11, '2000.00', 8, '2021-11-23 14:01:58', 1, 1, 'img_producto.png'),
(7, 'Monitor', 9, '2200.00', 75, '2021-11-23 14:01:58', 1, 1, 'img_1328286905ecc9eec8e81b94fa1786b9.jpg'),
(8, 'usb', 11, '160.00', 75, '2021-11-23 14:01:58', 1, 1, 'img_cce86641de32660a29e0fa49f58a950c.jpg'),
(9, '', 11, '45.00', 0, '2021-11-23 14:01:58', 1, 1, 'img_producto.png'),
(10, '', 11, '45.00', 0, '2021-11-23 14:04:33', 1, 1, 'img_producto.png'),
(11, '', 11, '45.00', 0, '2021-11-23 14:05:37', 1, 1, 'img_producto.png'),
(12, '', 11, '45.00', 0, '2021-11-23 14:07:09', 1, 1, 'img_producto.png'),
(13, 'sp', 11, '1222.00', 33, '2021-11-23 14:09:46', 1, 1, 'img_465aaf96de3a3a5901f9ee1f61e1a40fjpg'),
(14, 'sp', 11, '1222.00', 33, '2021-11-23 14:10:24', 1, 1, 'img_0b7d89d110a98f3480bac48778808a76jpg'),
(15, 'usb', 7, '56.00', 5, '2021-11-23 14:11:24', 1, 1, 'img_0b7d89d110a98f3480bac48778808a76jpg'),
(16, 'usb', 7, '56.00', 5, '2021-11-23 14:14:21', 1, 1, 'img_06796c036e350214b19d7d80b6a01f27.jpg'),
(17, 'usb', 7, '54.00', 2, '2021-11-23 14:15:01', 1, 1, 'img_e9ef50bc4bfd6f613d11ba11ffd08a4e.jpg'),
(18, 'usb', 7, '54.00', 2, '2021-11-23 14:22:27', 1, 1, 'img_426eb10771f373490cea0ce95298402e.jpg'),
(19, 'Lenovo i3', 2, '2900.00', 5, '2021-11-23 17:47:59', 1, 1, 'img_e998f36364d95f4e35be8fc8c8ec3da6.jpg'),
(20, 'cuaderno', 12, '12.00', 22, '2021-11-23 21:00:25', 1, 1, 'img_8c3a1171c118dad838cd71091eb4fb05.jpg'),
(21, 'cartuchera-frozen', 6, '13.00', 6, '2021-11-24 15:43:46', 1, 1, 'img_6ba28aaba83d3f1c1438fc90175145f3.jpg');

--
-- Disparadores `producto`
--
DELIMITER $$
CREATE TRIGGER `entradas_A_I` AFTER INSERT ON `producto` FOR EACH ROW BEGIN
		INSERT INTO entradas(codproducto,cantidad,precio,usuario_id) 
		VALUES(new.codproducto,new.existencia,new.precio,new.usuario_id);    
	END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `idproveedor` int(11) NOT NULL,
  `proveedor` varchar(100) DEFAULT NULL,
  `contacto` varchar(100) DEFAULT NULL,
  `telefono` bigint(11) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `usuario_id` int(11) NOT NULL,
  `estatus` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`idproveedor`, `proveedor`, `contacto`, `telefono`, `direccion`, `fecha`, `usuario_id`, `estatus`) VALUES
(1, 'HP', 'Miguel Lopes', 989877889, 'Avenida los angeles', '2021-11-22 17:54:49', 1, 1),
(2, 'Lenovo', 'Jose Luis', 968562354, 'indoamerica', '2021-11-22 17:54:49', 2, 1),
(3, 'Dell', 'Pedro Lopez', 982877489, 'Av. los laureles', '2021-11-22 17:54:49', 1, 1),
(4, 'Toshiba', 'Pedro Barturen', 947483647, 'villa el salvador', '2021-11-22 17:54:49', 1, 1),
(5, 'Conversiones Aymara', 'Aymara Yulissa', 9564535676, 'la providencia', '2021-11-22 17:54:49', 1, 1),
(6, 'Ayj Librerías', 'Fernanda Guerrero', 9578987678, 'cutervo', '2021-11-22 17:54:49', 1, 1),
(7, 'Comercial Giova S.A.', 'Gloria fernandez', 99879889, 'el porvenir', '2021-11-22 17:54:49', 1, 1),
(8, 'Van Dyck. Avenida', 'Julia lozano', 989476787, 'san luis de lucma', '2021-11-22 17:54:49', 1, 1),
(9, 'Pizarras Danny', 'Danny Vergaray', 9476378276, 'mexico y laureles', '2021-11-22 17:54:49', 1, 1),
(10, 'Distribuidora el Aguila', 'Lucio peres', 9788376787, 'las americas', '2021-11-22 17:54:49', 1, 1),
(11, 'Assus', 'Yober Cabrera', 947483647, 'culpon', '2021-11-22 17:54:49', 2, 1),
(12, 'Lay Consa', 'Wilmer Peralta', 956823567, 'las americas', '2021-11-22 17:54:49', 1, 1),
(13, 'C y F', 'Jaqueline ', 965325698, 'los amautas', '2021-11-22 18:16:37', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `idrol` int(11) NOT NULL,
  `rol` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`idrol`, `rol`) VALUES
(1, 'Administrador'),
(2, 'Supervisor'),
(3, 'Vendedor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `usuario` varchar(15) DEFAULT NULL,
  `clave` varchar(100) DEFAULT NULL,
  `rol` int(11) DEFAULT NULL,
  `estatus` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idusuario`, `nombre`, `correo`, `usuario`, `clave`, `rol`, `estatus`) VALUES
(1, 'Kelkin Lozano', 'kelkinheimin@gmail.com', 'Admin', '827ccb0eea8a706c4c34a16891f84e7b', 1, 1),
(2, 'Giancarlo', 'Giancarlo@gmail.com', 'Giancarlo', '827ccb0eea8a706c4c34a16891f84e7b', 2, 1),
(3, 'Tineo Santos', 'Tineo@gmail.com', 'Tineo', '827ccb0eea8a706c4c34a16891f84e7b', 3, 1),
(4, 'Jose pury', 'purihuaman@gmail.com', 'Josep', 'a763a66f984948ca463b081bf0f0e6d0', 3, 1),
(5, 'Ugaz Arenas', 'ugaz@gmail.com', 'ugaz', '827ccb0eea8a706c4c34a16891f84e7b', 2, 1),
(6, 'Carlos', 'carlos@gmail.com', 'carlos', 'dba0079f1cb3a3b56e102dd5e04fa2af', 3, 1),
(7, 'Matias Burga', 'matiasburga@gmail.com', 'matias', '02558a70324e7c4f269c69825450cec8', 2, 1),
(8, 'Jaqueline ', 'jaqueline @gmail.com', 'Jaqueline ', '69423f0c254e5c1d2b0f5ee202459d2c', 2, 1),
(9, 'Rosa Delgado', 'rosadelgado@gmail.com', 'rosa', '2c20cb5558626540a1704b1fe524ea9a', 1, 1),
(10, 'Paola Luna', 'paolaluna@gmail.com', 'paola', '52fd46504e1b86d80cfa22c0a1168a9d', 3, 1),
(11, 'Nicolas Smit', 'nicolas@gmail.com', 'nicolas', 'b89845d7eb5f8388e090fcc151d618c8', 2, 1),
(12, 'Lucas Miguel', 'lucas@hotmail.com', 'lucas', 'c1bfc188dba59d2681648aa0e6ca8c8e', 3, 1),
(13, 'Anthony Fredy', 'anthony@hotmail.com', 'anthony', 'fd820a2b4461bddd116c1518bc4b0f77', 3, 1),
(14, 'Cintia Margot', 'cintia@gmail.com', 'cintia', '64dd0133f9fb666ca6f4692543844f31', 3, 1),
(15, 'Thalia', 'thalia@hotmail.es', 'thalia', '32252792b9dccf239f5a5bd8e778dbc2', 3, 1),
(16, 'Eugenio Lozano', 'eugenio@gmail.com', 'eugenio', '827ccb0eea8a706c4c34a16891f84e7b', 2, 1),
(17, 'Amelida Delgado', 'amelida@gmail.com', 'amelida', '827ccb0eea8a706c4c34a16891f84e7b', 2, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idcliente`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `detallefactura`
--
ALTER TABLE `detallefactura`
  ADD PRIMARY KEY (`correlativo`),
  ADD KEY `codproducto` (`codproducto`),
  ADD KEY `nofactura` (`nofactura`);

--
-- Indices de la tabla `detalle_temp`
--
ALTER TABLE `detalle_temp`
  ADD PRIMARY KEY (`correlativo`),
  ADD KEY `nofactura` (`nofactura`),
  ADD KEY `codproducto` (`codproducto`);

--
-- Indices de la tabla `entradas`
--
ALTER TABLE `entradas`
  ADD PRIMARY KEY (`correlativo`),
  ADD KEY `codproducto` (`codproducto`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`nofactura`),
  ADD KEY `usuario` (`usuario`),
  ADD KEY `codcliente` (`codcliente`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`codproducto`),
  ADD KEY `proveedor` (`proveedor`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`idproveedor`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`idrol`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idusuario`),
  ADD KEY `rol` (`rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idcliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `detallefactura`
--
ALTER TABLE `detallefactura`
  MODIFY `correlativo` bigint(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detalle_temp`
--
ALTER TABLE `detalle_temp`
  MODIFY `correlativo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `entradas`
--
ALTER TABLE `entradas`
  MODIFY `correlativo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `nofactura` bigint(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `codproducto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  MODIFY `idproveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `idrol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`idusuario`);

--
-- Filtros para la tabla `detallefactura`
--
ALTER TABLE `detallefactura`
  ADD CONSTRAINT `detallefactura_ibfk_2` FOREIGN KEY (`codproducto`) REFERENCES `producto` (`codproducto`),
  ADD CONSTRAINT `detallefactura_ibfk_3` FOREIGN KEY (`nofactura`) REFERENCES `factura` (`nofactura`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `detalle_temp`
--
ALTER TABLE `detalle_temp`
  ADD CONSTRAINT `detalle_temp_ibfk_1` FOREIGN KEY (`nofactura`) REFERENCES `factura` (`nofactura`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detalle_temp_ibfk_2` FOREIGN KEY (`codproducto`) REFERENCES `producto` (`codproducto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `entradas`
--
ALTER TABLE `entradas`
  ADD CONSTRAINT `entradas_ibfk_1` FOREIGN KEY (`codproducto`) REFERENCES `producto` (`codproducto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `factura_ibfk_2` FOREIGN KEY (`codcliente`) REFERENCES `cliente` (`idcliente`),
  ADD CONSTRAINT `factura_ibfk_3` FOREIGN KEY (`usuario`) REFERENCES `usuario` (`idusuario`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`proveedor`) REFERENCES `proveedor` (`idproveedor`),
  ADD CONSTRAINT `producto_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`idusuario`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD CONSTRAINT `proveedor_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`idusuario`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`rol`) REFERENCES `rol` (`idrol`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
