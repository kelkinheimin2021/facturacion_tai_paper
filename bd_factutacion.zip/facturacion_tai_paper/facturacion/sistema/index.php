<?php 
	session_start();
?>

<!DOCTYPE html>
<html lang="es_ES">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sisteme Ventas</title>

	<!-- Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Dancing+Script|Raleway:500,600&display=swap" rel="stylesheet">
    
    <!--Materialice css-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    
    <!-- CSS Estilos -->
    <link rel="stylesheet" href="../css/style_carousel.css">

</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		<!--<h1>Sistemas de ventas TAI PAPER</h1>-->
	</section>
	
	<div class="container">
        <div class="row">
            <div class="col s12">
				<br>
                <h1 class="center-align titulo text-success">Bienvenido a TAI PAPER SAC</h1>

                <div class="carousel center-align">
                    <div class="carousel-item">
						<!--
                        <h2 class="subtitulo">Presentacion de la empresa</h2>
                        <div class="linea-division"></div>
                        <p class="sabor">Glaseadas</p>
-->
                        <img src="../img/presentacion_1.jpg" alt="presentacion_1">
                    </div>

                    <div class="carousel-item">
                        <img src="../img/presentacion_2.png" alt="presentacion_2">
                    </div>

                    <div class="carousel-item">
                        <img src="../img/presentacion_3.jpg" alt="presentacion_3">
                    </div>

                    <div class="carousel-item">
                        <img src="../img/presentacion_4.jpg" alt="presentacion_4">
                    </div>

                    <div class="carousel-item">
                        <img src="../img/presentacion_5.jpg" alt="presentacion_5">
                    </div>
                </div>
            </div>
        </div>
    </div>
    
	<!--Materialize.js-->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script> 

    <!-- JS Main -->
    <script src="../js/main.js"></script>

	<?php include "includes/footer.php"; ?>
</body>
</html>

