<?php 
	session_start();
	if($_SESSION['rol'] != 1 and $_SESSION['rol'] != 2)
	{
		header("location: ./");
	}

	include "../conexion.php";

	if(!empty($_POST))
	{
		$alert='';
		if(empty($_POST['proveedor']) || empty($_POST['contacto']) || empty($_POST['telefono']) || empty($_POST['direccion']))
		{
			$alert='<p class="msg_error">Todos los campos son obligatorios.</p>';
		}else{

			$proveedor = $_POST['proveedor'];
			$contacto = $_POST['contacto'];
			$telefono  = $_POST['telefono'];
			$direccion   = $_POST['direccion'];
			$usuario_id = $_SESSION['idUser'];
	
            
            $query = mysqli_query($conection,"SELECT * FROM proveedor WHERE proveedor = '$proveedor' ");
			$result = mysqli_fetch_array($query);

			if($result > 0){
				$alert='<p class="msg_error">El proveedor ya existe.</p>';
			}else{

            $query_insert = mysqli_query($conection,"INSERT INTO proveedor(proveedor, contacto,  telefono, direccion, usuario_id)
				VALUES('$proveedor', '$contacto', '$telefono', '$direccion', '$usuario_id')");

			if($query_insert){
				$alert='<p class="msg_save">Proveedor guardado satisfactoriamente.</p>';
			}else{
				$alert='<p class="msg_error">Error al registrar el proveedor.</p>';
			}
		}
		
	}
	mysqli_close($conection);

	}

?>


<!DOCTYPE html>
<html lang="es_ES">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php include "includes/scripts.php"; ?>
	<title>Registro Proveedor</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		
		<div class="form_register">
			<h1>Registro Proveedor</h1>
			<hr>
			<div class="alert"><?php echo isset($alert) ? $alert : ''; ?></div>

			<form action="" method="post">
                

				<label for="nombre">Proveedor</label>
				<input type="text" name="proveedor" id="proveedor" placeholder="Proveedor">

				<div class="row">
				<div class="col">
				<label for="dni">Contacto</label>
				<input type="text" name="contacto" id="contacto" placeholder="Contacto">
				</div>

				<div class="col">
                <label for="telefono">Telefono</label>
				<input type="number" name="telefono" id="telefono" placeholder="Teléfono">
				</div>
				</div>

                <!--
                <label for="fecha">Fecha</label>
				<input type="date" name="fecha" id="fecha">
-->

				<label for="direccion">Dirección</label>
				<input type="text" name="direccion" id="direccion" placeholder="Dirección">
				<br>

				<div class="row">
                    <div class="col">
                    <input type="submit" class="btn btn-outline-primary btn-block"  name="registrarProveedor" value="Registrar">
                    </div>

					<div class="col">
                    <a class="btn btn-outline-success btn-block" href="lista_Proveedores.php" role="button">Listar</a>
                    </div>

                    <div class="col">
                    <input type="reset" class="btn btn-outline-danger btn-block"  name="cancelarProveedor" value="Cancelar">
                    </div>
                </div>

			</form>


		</div>


	</section>
	<?php include "includes/footer.php"; ?>
</body>
</html>