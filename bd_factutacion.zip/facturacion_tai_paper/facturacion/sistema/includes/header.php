<?php 

	if(empty($_SESSION['active']))
	{
		header('location: ../');
	}
 ?>
	<header>
		<div class="header">

			<img src="../img/Logo_Tai_Paper.jpg" width="35" alt="Imagen_logo"/>
			<h4>TAI PAPER SAC</h4>

			<div class="optionsBar">
				
				<p>Perú, <?php echo fecha(); ?></p>
				<span>|</span>
				<span class="user"><?php echo $_SESSION['user'].' -'.$_SESSION['rol'].' -'.$_SESSION['email']; ?></span>
				<img class="photouser" src="../img/perfil.png" alt="Usuario">
				<a href="salir.php"><img class="close" src="../img/send-file.png" alt="Salir del sistema" title="Salir"></a>
			</div>
		</div>
		<?php include "nav.php"; ?>
	</header>