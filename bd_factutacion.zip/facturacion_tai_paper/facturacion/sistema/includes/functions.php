<?php
    date_default_timezone_set('America/Lima');

    function fecha()
    {
        $mes = array("","Enero",
                        "Febreo",
                        "Marzo",
                        "Abril",
                        "Mayo",
                        "Junio",
                        "Julio",
                        "Agosto",
                        "Septimebre",
                        "Octubre",
                        "Noviembre",
                        "Dicembre");
        return date('d'). " de ". $mes[date('m')]. " de ". date('Y'); 
    }
?>