<?php 
	
	session_start();
	if($_SESSION['rol'] != 1)
	{
		header("location: ./");
	}

	include "../conexion.php";

	if(!empty($_POST))
	{
		$alert='';
		if(empty($_POST['proveedor']) || empty($_POST['contacto']) || empty($_POST['telefono']) || empty($_POST['direccion']))
		{
			$alert='<p class="msg_error">Todos los campos son obligatorios.</p>';
		}else{

			$idproveedor = $_POST['id'];
			$proveedor = $_POST['proveedor'];
			$contacto  = $_POST['contacto'];
			$telefono  = $_POST['telefono'];
			$direccion = $_POST['direccion'];

        
            $query = mysqli_query($conection,"SELECT * FROM proveedor 
                WHERE (proveedor = '$proveedor' AND idproveedor != $idproveedor) ");

            $result = mysqli_fetch_array($query);

			if($result > 0){
				$alert='<p class="msg_error">El proveedor ya existe.</p>';
			}else{

				$sql_update = mysqli_query($conection,"UPDATE proveedor
										SET proveedor='$proveedor',
                                        contacto = '$contacto', 
										telefono='$telefono',direccion='$direccion'
										WHERE idproveedor= $idproveedor");
				
				if($sql_update){
					$alert='<p class="msg_save">Proveedor modificado correctamente.</p>';
				}else{
					$alert='<p class="msg_error">Error al modificar el proveedor.</p>';
				}

			}

		}

	}

	//Mostrar Datos
	if(empty($_REQUEST['id']))
	{
		header('Location: lista_proveedores.php');
		mysqli_close($conection);
	}
	$idproveedor = $_REQUEST['id'];

	$sql= mysqli_query($conection,"SELECT * FROM proveedor									WHERE idproveedor = $idproveedor ");

	mysqli_close($conection);

	$result_sql = mysqli_num_rows($sql);

	if($result_sql == 0){
		header('Location: lista_proveedores.php');
	}else{
		
		while ($data = mysqli_fetch_array($sql)) {
			# code...
			$idproveedor = $data['idproveedor'];
			$proveedor   = $data['proveedor'];
			$contacto    = $data['contacto'];
			$telefono    = $data['telefono'];
			$direccion   = $data['direccion'];

		}
	}

?>

<!DOCTYPE html>
<html lang="es_ES">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php include "includes/scripts.php"; ?>
	<title>Editar Proveedor</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		
		<div class="form_register">
			<h1>Editar Proveedor</h1>
			<hr>
			<div class="alert"><?php echo isset($alert) ? $alert : ''; ?></div>

            <form action="" method="post">

                <input type="hidden" name="id" value="<?php echo $idproveedor; ?>">                

				<label for="nombre">Proveedor</label>
				<input type="text" name="proveedor" id="proveedor" placeholder="Proveedor" value="<?php echo $proveedor; ?>">

				<div class="row">
				<div class="col">
                <label for="contacto">Contacto</label>
				<input type="text" name="contacto" id="contacto" placeholder="contacto" value="<?php echo $contacto; ?>">
				</div>

				<div class="col">
                <label for="telefono">Telefono</label>
				<input type="number" name="telefono" id="telefono" placeholder="Teléfono" value="<?php echo $telefono; ?>">
				</div>
				</div>

				<label for="direccion">Dirección</label>
				<input type="text" name="direccion" id="direccion" placeholder="Dirección" value="<?php echo $direccion; ?>">
				<br>

				<div class="row">
                    <div class="col">
                    <input type="submit" class= "btn btn-outline-success btn-block"  name="registrarProveedor" value="Modificar">
                    </div>

                    <div class="col">
                    <a class="btn btn-outline-primary btn-block" href="lista_proveedores.php" role="button">Salir</a>
                    </div>

                    <div class="col">
                    <input type="reset" class="btn btn-outline-danger btn-block"  name="cancelarProveedor" value="Cancelar">
                    </div>
                </div>

			</form>

		</div>


	</section>
	<?php include "includes/footer.php"; ?>
</body>
</html>