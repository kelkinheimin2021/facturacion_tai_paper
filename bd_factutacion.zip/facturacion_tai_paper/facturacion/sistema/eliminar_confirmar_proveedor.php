<?php 
	session_start();
	if($_SESSION['rol'] != 1 || $_SESSION['rol'] != 2)
	{
		//header("location: ./");
	}
	include "../conexion.php";

	if(!empty($_POST))
	{
		if(empty ($_POST['idproveedor']))
        {
            header("location: lista_proveedores.php");
            mysqli_close($conection);
        }
		$idproveedor = $_POST['idproveedor'];

		//$query_delete = mysqli_query($conection,"DELETE FROM usuario WHERE idusuario =$idusuario ");
		$query_delete = mysqli_query($conection,"UPDATE proveedor SET estatus = 0 WHERE idproveedor = $idproveedor ");
		mysqli_close($conection);
		if($query_delete){
			header("location: lista_proveedores.php");
		}else{
			echo "Error al eliminar";
		}

	}


	if(empty($_REQUEST['id']))
	{
		header("location: lista_proveedores.php");
		mysqli_close($conection);
	}else{

		$idproveedor = $_REQUEST['id'];

		$query = mysqli_query($conection,"SELECT * FROM proveedor
									WHERE idproveedor = $idproveedor");
		
		mysqli_close($conection);
        
		$result = mysqli_num_rows($query);

		if($result > 0){
			while ($data = mysqli_fetch_array($query)) {
				# code...
				$proveedor = $data['proveedor'];
				$contacto  = $data['contacto'];
				$direccion = $data['direccion'];
			}
		}else{
			header("location: lista_proveedores.php");
		}

	}

?>

<!DOCTYPE html>
<html lang="es_ES">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php include "includes/scripts.php"; ?>
	<title>Eliminar Proveedor</title>

</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		<div class="data_delete">
			<h2>Está seguro de elmiminar el proveedor seleccionado</h2>
			<p>Proveedor: <span><?php echo $proveedor; ?></span></p>
			<p>Contacto: <span><?php echo $contacto; ?></span></p>
			<p>Direccion: <span><?php echo $direccion; ?></span></p>

			<form method="post" action="">
                <input type="hidden" name="idproveedor" value="<?php echo $idproveedor; ?>">
				<a href="lista_proveedores.php" class="btn_cancel">Cancelar</a>
				<input type="submit" value="Aceptar" class="btn_ok">

			</form>
		</div>

	</section>
	<?php include "includes/footer.php"; ?>
</body>
</html>